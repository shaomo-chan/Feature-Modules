MODDIR=${0%/*}
mount --bind $MODDIR/my_product/etc/extension/com.oplus.app-features.xml /my_product/etc/extension/com.oplus.app-features.xml
mount --bind $MODDIR/my_product/etc/extension/com.oplus.oplus-feature.xml /my_product/etc/extension/com.oplus.oplus-feature.xml
mount --bind $MODDIR/my_product/etc/permissions/oplus.product.feature_multimedia_unique.xml /my_product/etc/permissions/oplus.product.feature_multimedia_unique.xml
mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml
mount --bind $MODDIR/my_product/etc/string_super_computing.zip /my_product/etc/string_super_computing.zip
mount --bind $MODDIR/my_product/etc/super_computing_config.json /my_product/etc/super_computing_config.json
mount --bind $MODDIR/my_product/etc/refresh_rate_config.xml /my_product/etc/refresh_rate_config.xml
mount --bind $MODDIR/my_product/etc/permissions/oplus.product.features_gameeco_unique.xml /my_product/etc/permissions/oplus.product.features_gameeco_unique.xml
mount --bind $MODDIR/my_product/etc/permissions/oplus.feature.control_cn_gms.xml /my_product/etc/permissions/oplus.feature.control_cn_gms.xml
mount --bind $MODDIR/my_product/etc/permissions/oplus_google_cn_gms_features.xml /my_product/etc/permissions/oplus_google_cn_gms_features.xml
mount --bind $MODDIR/my_region/etc/battery/sys_deviceidle_whitelist.xml /my_region/etc/battery/sys_deviceidle_whitelist.xml