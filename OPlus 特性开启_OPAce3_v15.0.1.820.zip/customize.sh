#!/system/bin/sh

# ==============================================
# Magisk 模块安装脚本
# ==============================================

### 1. 模块基础设置 ###
SKIPMOUNT=false      # 正常挂载模块文件
PROPFILE=true        # 使用 module.prop 定义模块属性
POSTFSDATA=true      # 在 post-fs-data 阶段执行（较早阶段）
LATESTARTSERVICE=true # 允许延迟启动服务（优化系统启动速度）

### 2. 检测 Root 环境 ###
if [ "$BOOTMODE" = true ]; then
    # 如果是 Magisk 环境，查找 mirror 目录（Magisk 的挂载隔离机制）
    ROOT=$(find "$(magisk --path)" -type d -name "mirror" | head -n 1)
    ui_print "- 检测到 Magisk 环境，Root 路径: $ROOT"
else
    # 非 Magisk 环境（如 TWRP 刷入）
    ROOT=""
    ui_print "- 非 Magisk 环境，跳过 Root 路径检测"
fi

### 3. 替换系统 hosts 文件 ###
ui_print "- 正在替换 hosts 文件..."
TARGET_PATH="/system/etc"
mkdir -p "$MODPATH$TARGET_PATH"  # 在模块目录创建对应路径
mv -f "$MODPATH/hosts" "$MODPATH$TARGET_PATH"  # 移动自定义 hosts 文件

### 4. 清理临时文件 & 设置权限 ###
rm -rf "$MODPATH/hosts"  # 删除临时文件（如果存在）
set_perm_recursive "$MODPATH" 0 0 0755 0644  # 设置模块文件权限（可执行+可读）

### 5. 获取模块和设备信息 ###
MODULE_NAME=$(grep 'name=' "$MODPATH/module.prop" | cut -d '=' -f2)
MODULE_VERSION=$(grep 'version=' "$MODPATH/module.prop" | cut -d '=' -f2)
MODULE_AUTHOR=$(grep 'author=' "$MODPATH/module.prop" | cut -d '=' -f2)
PHONE_MODEL=$(getprop ro.product.model)  # 手机型号
CURRENT_TIME=$(date "+%Y-%m-%d %H:%M:%S")  # 当前时间

### 6. 显示安装信息 ###
ui_print "══════════════════════════════════════"
ui_print "  模块名称: $MODULE_NAME"
ui_print "  版本号: v$MODULE_VERSION"
ui_print "  作者: $MODULE_AUTHOR"
ui_print "  设备型号: $PHONE_MODEL"
ui_print "  安装时间: $CURRENT_TIME"
ui_print "══════════════════════════════════════"
ui_print ""
ui_print "即将跳转到作者酷安主页，欢迎关注支持！"
ui_print "3 秒后自动跳转..."

### 7. 倒计时跳转 ###
for i in 3 2 1; do
    ui_print "倒计时: $i 秒..."
    sleep 1
done

# 尝试用浏览器打开作者主页
am start -a android.intent.action.VIEW -d "https://www.coolapk.com/u/9297276" >/dev/null 2>&1

### 8. 结束提示 ###
ui_print ""
ui_print "提示: 如果没有自动跳转，请手动访问:"
ui_print "https://www.coolapk.com/u/9297276"
ui_print "感谢您的支持！❤️"

exit 0  # 正常退出