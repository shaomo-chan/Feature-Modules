#!/system/bin/sh

# 等待系统启动完成（避免过早执行）
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done

# 禁用 dm-verity 和 AVB 验证
avbctl disable-verity --force
avbctl disable-verification --force